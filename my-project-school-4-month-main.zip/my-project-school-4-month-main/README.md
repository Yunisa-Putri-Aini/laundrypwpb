# my-project-school-4-month
Tugas project 4 bulan

fitur admin  :
-login
-dashboard
-CRUD pelanggan
-CRUD outlet
-CRUD paket
-transaksi
-generate laporan
-logout

fitur kasir  :
-login
-dashboard
-CRUD pelanggan
-transaksi
-generate laporan
-logout

fitur kasir  :
-login
-dashboard
-generate laporan
-logout

